# House Price Analysis App

A Streamlit application for analyzing house price data with an intuitive, clean interface inspired by Apple's design principles.

## Features

- CSV file upload and preview
- Interactive price trend visualization
- Location-based price analysis
- Summary statistics
- Clean, minimalist design

## Installation

1. Install the required dependencies:
streamlit
pandas
seaborn
matplotlib
plotly
numpy

##Usage 

1. Start streamlit app by running the following command: streamlit run Housingapp.py

2. Upload a CSV file containing house price data.

The CSV file should have the following columns:
- Date (YYYY-MM-DD format)
- Price (numeric)
- Bedrooms (numeric)
- Bathrooms (numeric)
- SquareMeter (numeric)
- Location (text)

## Sample Data from housing_prices.csv

Date,Price,Bedrooms,Bathrooms,SquareMeter,Location
2024-01-01,500000,3,2,139.35,North Wollongong
2024-02-01,520000,4,2,148.64,South Wollongong
2024-03-01,550000,3,2,144,North Wollongong
2024-04-01,490000,2,1,111.48,South Wollongong
2024-05-01,600000,4,3,167.23,East Wollongong
2024-06-01,530000,3,2,148.64,West Wollongong
2024-07-01,580000,4,3,162.58,North Wollongong
2024-08-01,510000,3,2,144,East Wollongong
2024-09-01,620000,4,3,171.87,South Wollongong
2024-10-01,540000,3,2,153.29,West Wollongong
2024-11-01,590000,4,3,157.93,North Wollongong
2024-12-01,520000,3,2,148.64,East Wollongong

## If I was hired as a Penetration Tester. ]
Like in my imageapp.py I tested this application for vulnerabilities, and yet again I found come vulnerabilities!

Here are some which I found:

Firstly, the file uploaded (st.file_uploader) acceots user-supplied files without verifying the content of teh uploaded files. Attacker could upload files with unexpected extentions (.exe, .php) dishuised as a .csv. Additionally, they can upload malformed or malcious CSV fles that exploit the applicaation, especially if the CSV contains formulas or script (e.g in cells starting with =, @, and +)

Exploit could be:
Location,Price,SquareMeter,Bedrooms,Bathrooms
"Home","=cmd|'/C calc'!A0",120,3,2
if this file is later opened in Excel for example it could execute commands like launching the calculator application.

To mitigate this we can ensure the file is a valid CSV file by examining its structure:
try:
    df = pd.read_csv(uploaded_file)
except pd.errors.ParserError:
    st.error("Invalid CSV file. Please upload a valid CSV.")
    return

Additionally, we can also strip dangerous just like our example in imageapp.py
df = df.replace(to_replace=r"^[=+\-@]", value="", regex=True)

The second vulnerbaility which I found and is also present in the imageapp.py is a DoS (Denial of service) where teh st.file_uploader allows users to uplaod files of any size which could lead to a memory overflow or crash the application.

If someone were to upload a CSV file for 10GB or more it could crash teh server or deplete its storage completely.

To mitigate this we can set a maximum file size limit for the uploaded files, for example:

MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024  # 10GB

if uploaded_file.size > MAX_FILE_SIZE:
    st.error("File size exceeds the maximum limit of 10GB.")
    return

The third vulnerability which I found is an injection attack on column names, if column names from a CSV are directly used without sanitisation, an attacker could inject malicious code via column names. This is the code which I found the vulnerability in:

numeric_cols = ['Price', 'Bedrooms', 'Bathrooms', 'SquareMeter', 'PricePerSqm']
correlation_matrix = df[numeric_cols].corr()

an attacker could inject malicious code via column names like this for example:

`Price`; DROP TABLE USERS;--,Bedrooms,Bathrooms,SquareMeter,PricePerSqm

this could break the applications code logic.

To fix this we can use a whitelist of allowed column names and reject any column names that are not in the whitelist, for example:

allowed_cols = ['Price', 'Bedrooms', 'Bathrooms', 'SquareMeter', 'PricePerSqm']
df = df[df.columns.intersection(allowed_cols)]

The fourth vulnerability is again with the unsanitised user input which we can upload a string instead of numbers in teh Price column. 

Location,Price,SquareMeter,Bedrooms,Bathrooms
City1,INVALID,100,3,2

To fix this we ensure all columns contain valid data.

if not pd.api.types.is_numeric_dtype(df['Price']):
    st.error("Invalid data in Price column. Please upload a valid dataset.")
    return

The fifth vulnerability is within the loops in which the application calculates the data, teh application lopps over the uplaoded data and calculated the metrics dynamically, if the dataset it too large, it could cause performance bottlenecks or even crash the application.

If we uplaod a set with millions of rows it could cause excessive CPU or memory storage.

To fix this we can implemet a row limit by setting data limits. 

MAX_ROWS = 10000
if len(df) > MAX_ROWS:
    st.error("Dataset too large! Please upload a file with fewer rows.")
    return

The sixth and last vulnerabiltty I found is XSS (Cross-Site Scripting) where an attacker can inject malicious scripts into the application, and it could show sensitive information to the user.

The dynamic outputs like st.metric, st.markdown, or st.plotly_chart could render malicious content, injected within the uploaded file.

The attacker could upload a CSV file with malicious data like this:
Location,Price,SquareMeter,Bedrooms,Bathrooms
"<script>alert('XSS');</script>",100000,200,3,2
The app will render this data which will execute in the user's browser.

To mitigate this we can escape HTML/JS contest using 'escape' to sanitise potenial malicious data.

from html import escape
df['Location'] = df['Location'].apply(escape)

