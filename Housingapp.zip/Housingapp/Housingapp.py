import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
import numpy as np

# Page configuration
st.set_page_config(
    page_title="Data Analysis Dashboard",
    page_icon="📊",
    layout="wide"
)

# Hide the raw CSS from being displayed
st.markdown("""
    <style>
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Main background */
    .stApp {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    }
    
    /* Button styling */
    .stButton > button {
        width: 200px;
        border-radius: 50px;
        background-color: rgba(26, 26, 46, 0.95);
        color: #ffffff;
        border: 2px solid #2594FF;
        padding: 10px 20px;
        transition: all 0.3s ease;
        transform-style: preserve-3d;
        position: relative;
    }
    
    .stButton > button:hover {
        transform: translate(5px, -5px);
        background-color: #2594FF;
        color: white;
    }
    
    .stButton > button::before {
        content: '';
        position: absolute;
        bottom: -5px;
        left: -5px;
        width: 100%;
        height: 5px;
        background: #00ff95;
        transform: skewX(-41deg);
        opacity: 0;
        transition: 0.3s;
    }
    
    .stButton > button:hover::before {
        opacity: 1;
    }
    
    /* Rest of your existing styles */
    .stSelectbox {
        background: rgba(26, 26, 46, 0.95);
        border-radius: 8px;
        padding: 5px;
        margin-bottom: 20px;
    }
    
    .stFileUploader {
        background: rgba(26, 26, 46, 0.95);
        padding: 20px;
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Text colors */
    .stMarkdown, .stText {
        color: white !important;
    }
    
    div[data-testid="stMetricValue"] {
        color: #00ff95 !important;
    }
    </style>
""", unsafe_allow_html=True)

# Load the house_prices.csv file
@st.cache_data
def load_data():
    return pd.read_csv('house_prices.csv')

# Main app code
st.title("Data Analysis Dashboard")

# File uploader section
uploaded_file = st.file_uploader("Choose a CSV file", type="csv")

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
else:
    df = load_data()
    st.info("👆 Currently showing example housing data. Upload your own CSV file to analyze different data.")

# Overview Section
st.header("Market Overview")
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Average Price", f"${df['Price'].mean():,.2f}")
with col2:
    st.metric("Total Properties", len(df))
with col3:
    st.metric("Price Range", f"${df['Price'].max() - df['Price'].min():,.2f}")
with col4:
    st.metric("Avg. Size", f"{df['SquareMeter'].mean():.1f} m²")

# Price Analysis
st.header("Price Analysis")
price_tab1, price_tab2 = st.tabs(["Distribution", "Trends"])

with price_tab1:
    col1, col2 = st.columns(2)
    with col1:
        # Price distribution
        fig = px.histogram(df, x="Price", nbins=30,
                          title="Price Distribution",
                          labels={"Price": "Price ($)", "count": "Number of Properties"})
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Price box plot by location
        fig = px.box(df, x="Location", y="Price",
                    title="Price Distribution by Location",
                    labels={"Price": "Price ($)", "Location": "Area"})
        fig.update_xaxes(tickangle=45)
        st.plotly_chart(fig, use_container_width=True)

with price_tab2:
    # Price vs Square Meter scatter plot
    fig = px.scatter(df, x="SquareMeter", y="Price", color="Location",
                    title="Price vs Property Size",
                    labels={"SquareMeter": "Area (m²)", "Price": "Price ($)"})
    st.plotly_chart(fig, use_container_width=True)

# Location Analysis
st.header("Location Analysis")
location_counts = df['Location'].value_counts()

col1, col2 = st.columns(2)
with col1:
    # Properties by location pie chart
    fig = px.pie(values=location_counts.values, names=location_counts.index,
                 title="Properties by Location")
    st.plotly_chart(fig, use_container_width=True)

with col2:
    # Average price by location bar chart
    avg_price_by_location = df.groupby('Location')['Price'].mean().reset_index()
    fig = px.bar(avg_price_by_location, x='Location', y='Price',
                 title="Average Price by Location",
                 labels={"Price": "Average Price ($)", "Location": "Area"})
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)

# Property Features Analysis
st.header("Property Features Analysis")
features_tab1, features_tab2 = st.tabs(["Size Distribution", "Room Analysis"])

with features_tab1:
    col1, col2 = st.columns(2)
    with col1:
        # Square meter distribution
        fig = px.histogram(df, x="SquareMeter", nbins=20,
                          title="Property Size Distribution",
                          labels={"SquareMeter": "Area (m²)", "count": "Number of Properties"})
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Average size by location
        avg_size_by_location = df.groupby('Location')['SquareMeter'].mean().reset_index()
        fig = px.bar(avg_size_by_location, x='Location', y='SquareMeter',
                     title="Average Property Size by Location",
                     labels={"SquareMeter": "Average Area (m²)", "Location": "Area"})
        fig.update_xaxes(tickangle=45)
        st.plotly_chart(fig, use_container_width=True)

with features_tab2:
    col1, col2 = st.columns(2)
    with col1:
        # Bedrooms distribution
        bedroom_counts = df['Bedrooms'].value_counts().sort_index()
        fig = px.bar(x=bedroom_counts.index, y=bedroom_counts.values,
                    title="Number of Bedrooms Distribution",
                    labels={"x": "Bedrooms", "y": "Count"})
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Bathrooms distribution
        bathroom_counts = df['Bathrooms'].value_counts().sort_index()
        fig = px.bar(x=bathroom_counts.index, y=bathroom_counts.values,
                    title="Number of Bathrooms Distribution",
                    labels={"x": "Bathrooms", "y": "Count"})
        st.plotly_chart(fig, use_container_width=True)

# Price per Square Meter Analysis
st.header("Price per Square Meter Analysis")
df['PricePerSqm'] = df['Price'] / df['SquareMeter']

col1, col2 = st.columns(2)
with col1:
    # Price per square meter by location
    avg_price_per_sqm = df.groupby('Location')['PricePerSqm'].mean().reset_index()
    fig = px.bar(avg_price_per_sqm, x='Location', y='PricePerSqm',
                 title="Average Price per Square Meter by Location",
                 labels={"PricePerSqm": "Price per m² ($)", "Location": "Area"})
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)

with col2:
    # Price per square meter distribution
    fig = px.box(df, x="Location", y="PricePerSqm",
                 title="Price per Square Meter Distribution by Location",
                 labels={"PricePerSqm": "Price per m² ($)", "Location": "Area"})
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)

# Correlation Analysis
st.header("Feature Correlations")
numeric_cols = ['Price', 'Bedrooms', 'Bathrooms', 'SquareMeter', 'PricePerSqm']
correlation_matrix = df[numeric_cols].corr()

fig = px.imshow(correlation_matrix,
                labels=dict(color="Correlation"),
                title="Feature Correlation Matrix")
st.plotly_chart(fig, use_container_width=True)

# Add helpful instructions
with st.expander("How to Use This Dashboard"):
    st.markdown("""
    1. **Upload Data**: Use the file uploader to analyze your own CSV file
    2. **Market Overview**: Quick summary of key metrics
    3. **Price Analysis**: 
        - View price distribution and trends
        - Compare prices across locations
    4. **Location Analysis**: 
        - Property distribution by area
        - Price comparisons across locations
    5. **Property Features**: 
        - Size distribution analysis
        - Room configuration statistics
    6. **Price per Square Meter**: 
        - Value analysis by location
        - Distribution comparisons
    7. **Correlations**: 
        - Understand relationships between features
    """)